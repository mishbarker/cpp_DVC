//============================================================================
// Name        : BarkerA02.cpp
// Author      : Michelle Barker
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {
	cout << "!!!Hello There World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
